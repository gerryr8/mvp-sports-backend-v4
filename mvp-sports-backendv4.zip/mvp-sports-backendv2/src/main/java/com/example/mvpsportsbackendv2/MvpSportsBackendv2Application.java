package com.example.mvpsportsbackendv2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MvpSportsBackendv2Application {

    public static void main(String[] args) {
        SpringApplication.run(MvpSportsBackendv2Application.class, args);
    }

}
