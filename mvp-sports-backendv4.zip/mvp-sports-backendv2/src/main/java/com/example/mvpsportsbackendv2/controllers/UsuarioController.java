package com.example.mvpsportsbackendv2.controllers;

import java.util.ArrayList;
import java.util.Optional;

import com.example.mvpsportsbackendv2.models.UsuarioModel;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;


@RestController
@RequestMapping("/usuario")
@CrossOrigin(origins = "http://localhost:4200")
public class UsuarioController {

}